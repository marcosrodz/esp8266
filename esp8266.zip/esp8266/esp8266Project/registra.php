<?php
    include 'conecta.php';
    $temp = $_GET['temp'];
    $sql = "INSERT INTO `controlador` (`data`, `temperatura`) VALUES (current_timestamp(), '$temp');";
    mysqli_query($conn,$sql);
    mysqli_close($conn)
?>