<?php
    include 'conecta.php';
    $sqlUltimaTemp = "SELECT temperatura from controlador where id = (select max(id) from controlador)";
    $sqlMedia = "SELECT AVG(temperatura) FROM controlador";
    $sqlMax = "SELECT MAX(temperatura) FROM controlador";
    $sqlMin = "SELECT MIN(temperatura) FROM controlador";
    $sqlDisp = "SELECT nome from controlador where id = (select max(id) from controlador)";
    
    $consultaUltimaTemp = mysqli_query($conn, $sqlUltimaTemp);
    $resultadoUltimaTemp = mysqli_fetch_array($consultaUltimaTemp);

    $consultaMedia = mysqli_query($conn, $sqlMedia);
    $resultadoMedia = mysqli_fetch_array($consultaMedia);

    $consultaMax = mysqli_query($conn, $sqlMax);
    $resultadoMax = mysqli_fetch_array($consultaMax);

    $consultaMin = mysqli_query($conn, $sqlMin);
    $resultadoMin = mysqli_fetch_array($consultaMin);

    $consultaDisp = mysqli_query($conn, $sqlDisp);
    $resultadoDisp = mysqli_fetch_array($consultaDisp);
?>

<?php
    if (isset($_POST['gravar'])) {
        include "conecta.php";
        $aqueceOn = $_POST['aquecedorL'];
        $aqueceOff = $_POST['aquecedorD'];
        $resfriaOn = $_POST['resfriadorL'];
        $resfriaOff = $_POST['resfriadorD'];
        $aqueceMA = $_POST['aqueceMA'];
        $aquece = $_POST['aqueceOn'];
        $resfriaMA = $_POST['resfriaMA'];
        $resfria = $_POST['resfriaOn'];
        $listBool = ["a" => 0, "b" => 1];
        header('Location: setpoint.php');
        mysqli_close($conn);
    } else {
        print "";
}
?>
<html>
    <body>
    <center>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <link href="estilo.css" rel="stylesheet"/>
    </head>
    <div class="p-3 mb-2 bg-dark text-white">
        <h2>Projeto esp8266</h2>
    </div>
    <br/><br/><br/><br/><br/>
    <div class="row justify-content-center row-cols-1 row-cols-md-2 mb-3 text-center">
        <div class="p-3 mb-2 bg-dark text-white" class="col">
            <div class="p-3 mb-2 bg-secondary text-white" class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="p-3 mb-2 bg-dark text-white" class="my-0 fw-normal"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
                    </svg>&nbsp;&nbsp;<b>Dados:</b></h4>
                </div>
                    <div class="card-body text-start">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                            <th scope="col">Ultima temperatura</th>
                            <th scope="col">Temperatura mínima</th>
                            <th scope="col">Temperatura máxima</th>
                            <th scope="col">Temperatura média</th>
                            <th scope="col">Último Dispositivo</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            print '<br/><br/>';   
                            print '<tr>';
                            print '<td>' . $resultadoUltimaTemp['temperatura'] . '</td>';
                            print '<td>'.$resultadoMin['MIN(temperatura)'] . '</td>';
                            print '<td>'. $resultadoMax['MAX(temperatura)'] . '</td>';
                            print '<td>'.$resultadoMedia['AVG(temperatura)'] . '</td>';
                            print '<td>'.$resultadoDisp['nome'] . '</td>';
                            print '</tr>';
                            mysqli_close($conn);
                        ?>
                        </tbody>
                        </table>
                        <form action = "exibe.php" method = "POST">
                        <div class="container text-center"><div class="row"><div class="col"></div><div class="col">
                            <button name = "gravar" type="submit" class="btn btn-outline-dark btn-lg" >Configurar Presets</button>
                        </div><div class="col"></div></div></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </center>
    </body>
</html>
