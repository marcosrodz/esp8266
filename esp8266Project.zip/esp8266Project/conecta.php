
<?php
	$conn = mysqli_connect("127.0.0.1","tds08","tds08top","ZeDouglasMarcos");
	// if($conn){
	// 	echo "yesss baby, tank you";
	// }
	?>