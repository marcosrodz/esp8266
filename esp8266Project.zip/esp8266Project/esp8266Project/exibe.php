<html><head><link href="estilo.css" rel="stylesheet"/><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head></html>
<?php
    include 'conecta.php';
    $sqlUltimaTemp = "SELECT temperatura from controlador where id = (select max(id) from controlador)";
    $sqlMedia = "SELECT AVG(temperatura) FROM controlador";
    $sqlMax = "SELECT MAX(temperatura) FROM controlador";
    $sqlMin = "SELECT MIN(temperatura) FROM controlador";
    $sqlDisp = "SELECT nome from controlador where id = (select max(id) from controlador)";
    
    $consultaUltimaTemp = mysqli_query($conn, $sqlUltimaTemp);
    $resultadoUltimaTemp = mysqli_fetch_array($consultaUltimaTemp);
    // print '<br/><b>Ultima temperatura registrada: </b><br/>'.$resultadoUltimaTemp['temperatura'];

    $consultaMedia = mysqli_query($conn, $sqlMedia);
    $resultadoMedia = mysqli_fetch_array($consultaMedia);
    // print '<br/><b>Temperatura maxima registrada: </b><br/>'.$resultadoMedia['AVG(temperatura)'];

    $consultaMax = mysqli_query($conn, $sqlMax);
    $resultadoMax = mysqli_fetch_array($consultaMax);
    // print '<br/><b>Temperaturas minima registrada: </b><br/>'.$resultadoMax['MAX(temperatura)'];

    $consultaMin = mysqli_query($conn, $sqlMin);
    $resultadoMin = mysqli_fetch_array($consultaMin);
    // print '<br/><b>Media das temperaturas registradas: </b><br/>'.$resultadoMin['MIN(temperatura)'];

    $consultaDisp = mysqli_query($conn, $sqlDisp);
    $resultadoDisp = mysqli_fetch_array($consultaDisp);
?>

<html>
    <body>
    <center>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    </head>
    <div class="p-3 mb-2 bg-dark text-white">
        <h2>Projeto esp8266</h2>
    </div>
    <hr/>
    <div class="row justify-content-center row-cols-1 row-cols-md-2 mb-3 text-center">
        <div class="p-3 mb-2 bg-dark text-white" class="col">
            <div class="p-3 mb-2 bg-secondary text-white" class="card mb-4 rounded-3 shadow-sm">
                <div class="card-header py-3">
                    <h4 class="p-3 mb-2 bg-dark text-white" class="my-0 fw-normal"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
                    </svg>&nbsp;&nbsp;<b>Dados:</b></h4>
                </div>
                    <div class="card-body text-start">
                    <table class="table table-dark table-striped">
                        <thead>
                            <tr>
                            <th scope="col">Ultima temperatura</th>
                            <th scope="col">Temperatura mínima</th>
                            <th scope="col">Temperatura máxima</th>
                            <th scope="col">Temperatura média</th>
                            <th scope="col">Último Dispositivo</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php

                            echo '<br/><br/>';   
                            echo '<tr>';
                            echo '<td>' . $resultadoUltimaTemp['temperatura'] . '</td>';
                            echo '<td>'.$resultadoMin['MIN(temperatura)'] . '</td>';
                            echo '<td>'. $resultadoMax['MAX(temperatura)'] . '</td>';
                            echo '<td>'.$resultadoMedia['AVG(temperatura)'] . '</td>';
                            echo '<td>'.$resultadoDisp['nome'] . '</td>';
                            echo '</tr>';
                            mysqli_close($conn)
                            ?>
                        </tbody>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/> -->
    </center>
    </body>
</html>