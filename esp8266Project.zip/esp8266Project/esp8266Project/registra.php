<?php
    include 'conecta.php';
    $temp = $_GET['temp'];
    $nome = $_GET['nome'];
    $sql = "INSERT INTO `controlador` (`data`, `temperatura`, `nome`) VALUES (current_timestamp(), '$temp', '$nome');";
    mysqli_query($conn,$sql);
    mysqli_close($conn)
?>