<?php
    include 'conecta.php';
    $temp = $_GET['temp'];
    $nome = $_GET['nome'];
    $sql = "INSERT INTO `controlador` (`data`, `temperatura`, `nome`) VALUES (current_timestamp(), '$temp', '$nome');";
    mysqli_query($conn,$sql);
    $sql1 = mysqli_query($conn, "SELECT * FROM setpoint");
    $result = mysqli_fetch_array($sql1);
    for ($i = 1; $i <= 8; $i++) {
        print $result[$i];
    }
    mysqli_close($conn)
?>