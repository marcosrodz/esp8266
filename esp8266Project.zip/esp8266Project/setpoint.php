<html>
    <body>
    <center>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <link href="estilo.css" rel="stylesheet"/>
    </head>
    <div class="p-3 mb-2 bg-dark text-white">
        <h2>SetPoints</h2>
    </div>
    <br/><br/><br/><br/><br/>
    <div class="row justify-content-center row-cols-1 row-cols-md-2 mb-3 text-center">
            <div class="p-3 mb-2 bg-dark text-white" class="col">
                <div class="p-3 mb-2 bg-secondary text-white" class="card mb-4 rounded-3 shadow-sm">
                    <div class="card-header py-3">
                        <h4 class="p-3 mb-2 bg-dark text-white" class="my-0 fw-normal"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-file-bar-graph" viewBox="0 0 16 16">
                        <path d="M4.5 12a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-1zm3 0a.5.5 0 0 1-.5-.5v-4a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-1zm3 0a.5.5 0 0 1-.5-.5v-6a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-.5.5h-1z"/>
                        <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z"/>
                        </svg>&nbsp;&nbsp;<b>Presets :</b></h4>
                    </div>
                        <div class="card-body text-start">
                            <form action = "setpoint.php" method = "POST">
                            <?php
                                include "conecta.php";
                                $sql = mysqli_query($conn, "SELECT * FROM setpoint");
                                $result = mysqli_fetch_array($sql);
                            ?>
                                <br/>
                                <div class="input-group mb-4">
                                    <span class="input-group-text">LIGA AQUECEDOR</span>
                                    <input type="number" name = "aquecedorL" class="form-control" value = <?php print $result[1];?>>
                                    <span class="input-group-text">DESLIGA AQUECEDOR</span>
                                    <input type="number" name = "aquecedorD" class="form-control" value = <?php print $result[2];?>>
                                </div>
                                <div class="input-group mb-4">
                                    <br/>
                                    <span class="input-group-text">LIGA RESFRIADOR</span>
                                    <input type="number" name = "resfriadorL" class="form-control" value = <?php print $result[3];?>>
                                    <span class="input-group-text">DESLIGA RESFRIADOR</span>
                                    <input type="number" name = "resfriadorD" class="form-control" value = <?php print $result[4];?>>
                                </div>
                                <div class="input-group mb-4">
                                    <br/>
                                    <span class="input-group-text">AQUECEDOR</span>
                                    <select class="form-select" name="aqueceMA">
                                        <?php if($result[5] == 0) {print "<option value = 0 selected>Auto</option> <option value = 1>Manual</option>";}else {
                                        print "<option value = 0>Auto</option> <option value = 1 selected>Manual</option>";}?>
                                    </select>
                                    <select class="form-select" name="aqueceOn">
                                        <?php if($result[7] == 0) {print "<option value = 0 selected>Desligado</option> <option value = 1>Ligado</option>";}else {
                                        print "<option value = 0>Desligado</option> <option value = 1 selected>Ligado</option>";}?>
                                    </select>
                                </div>
                                <div class="input-group mb-4">
                                    <br/>
                                    <span class="input-group-text">RESFRIADOR</span>
                                    <select class="form-select" name="resfriaMA">
                                        <?php if($result[6] == 0) {print "<option value = 0 selected>Auto</option> <option value = 1>Manual</option>";}else {
                                        print "<option value = 0>Auto</option> <option value = 1 selected>Manual</option>";}?>
                                    </select>
                                    <select class="form-select" name="resfriaOn">
                                        <?php if($result[8] == 0) {print "<option value = 0 selected>Desligado</option> <option value = 1>Ligado</option>";}else {
                                        print "<option value = 0>Desligado</option> <option value = 1 selected>Ligado</option>";}?>
                                    </select>
                                </div>
                                <div class="container text-center"><div class="row"><div class="col"></div><div class="col">
                                    <button name = "salvar" type="submit" class="btn btn-outline-dark btn-lg" >Salvar Presets</button>
                                </div><div class="col"></div></div></div>
                            </form>
                            <?php
                                if (isset($_POST['salvar'])) {
                                    include "conecta.php";
                                    $aqueceOn = $_POST['aquecedorL'];
                                    $aqueceOff = $_POST['aquecedorD'];
                                    $resfriaOn = $_POST['resfriadorL'];
                                    $resfriaOff = $_POST['resfriadorD'];
                                    $aqueceMA = $_POST['aqueceMA'];
                                    $resfriaMA = $_POST['resfriaMA'];
                                    $aquece = $_POST['aqueceOn'];
                                    $resfria = $_POST['resfriaOn'];
                                    if($aqueceMA == 0) {
                                        $aquece = 0;
                                    }
                                    if($resfriaMA == 0) {
                                        $resfria = 0;
                                    }
                                    $insertSetPoint = "UPDATE setpoint SET aqueceOn = $aqueceOn, aqueceOff = $aqueceOff, resfriaOn = $resfriaOn, resfriaOff = $resfriaOff,
                                    aqueceMA = $aqueceMA, resfriaMA = $resfriaMA, aqueceManualOn = $aquece, resfriaManualOn = $resfria WHERE id = 1";
                                    mysqli_query($conn,$insertSetPoint);
                                    mysqli_close($conn);
                                    header("Refresh:0");
                                } else {
                                    print "";
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </center>
    </body>
</html>